package com.roitraining.app.endpoints;

import static io.restassured.RestAssured.given;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

import org.apache.http.HttpStatus;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.roitraining.app.domain.OrderBook;
import com.roitraining.app.domain.OrderComplete;

import io.restassured.response.Response;


/**
 * 
 * This includes 7,8,10,
 * 12 - generate auto records,
 * 16 - security
 * @author student
 *
 */
public class Story10Test extends BaseTest {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Test 
	public void orderExecuted(){
		Response response = given().
		        when().
		        	get("/trade/loadData?loadCount=10").
		        then().
		        	statusCode(HttpStatus.SC_OK).
		        and().
		        	extract().response();
				
				OrderBook[] responseBody = response.as(OrderBook[].class);
			    assertNotNull(responseBody);
			    
			    assertThat("Data matches successfully",10,equalTo(responseBody.length));
		
		List<OrderBook> orderList = Arrays.asList(
	            new OrderBook("Test", "Buy", "Limit", 110.3, 415,Timestamp.valueOf("2017-02-02 14:42:50.078"))
				);
		
		
		
		
		
		 response = given().
				header("Content-Type", "application/json").
		body(orderList).
        when().
        	post("/trade/placeorder").
        then().
        	statusCode(HttpStatus.SC_OK).
        and().
        	extract().response();
		
		 OrderBook[] responseBody1 = response.as(OrderBook[].class);
		 assertNotNull(responseBody1);
		 log.info("return data"+responseBody1[0].toString());
		   assertThat("Order placed successfully",1,equalTo(responseBody1.length));
		    
		 response = given().
					header("Content-Type", "application/json").
			body(Arrays.asList(responseBody1)).
	        when().
	        	post("/trade/cancel").
	        then().
	        	statusCode(HttpStatus.SC_OK).
	        and().
	        	extract().response();
		
		 OrderBook[] responseBody2 = response.as(OrderBook[].class);
		 assertNotNull(responseBody2);
	    log.info("Cancelled order:"+responseBody2[0].toString());
	    assertThat("Order cancelled sucessfully",1,equalTo(responseBody2.length));
		
    }
	
}
