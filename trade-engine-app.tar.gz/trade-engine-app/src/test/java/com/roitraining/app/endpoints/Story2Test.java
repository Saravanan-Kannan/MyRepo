package com.roitraining.app.endpoints;

import static io.restassured.RestAssured.given;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import org.apache.http.HttpStatus;
import org.junit.Test;

import com.roitraining.app.domain.OrderBook;

import io.restassured.response.Response;

public class Story2Test extends BaseTest {

	@Test
	public void orderExecuted(){
		
		
		Response response = given().
        when().
        	get("/trade/loadData?loadCount=10").
        then().
        	statusCode(HttpStatus.SC_OK).
        and().
        	extract().response();
		
		OrderBook[] responseBody = response.as(OrderBook[].class);
	    assertNotNull(responseBody);
	    
	    assertThat("Data matches successfully",10,equalTo(responseBody.length));
		
    }
	
}
