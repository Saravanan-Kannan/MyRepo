package com.roitraining.app.endpoints;


import static io.restassured.RestAssured.given;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.roitraining.app.App;
import com.roitraining.app.domain.OrderBook;
import com.roitraining.app.domain.OrderComplete;

import io.restassured.RestAssured;
import io.restassured.response.Response;


public class StockExchangeControllerTest extends BaseTest{

	
	@Test 
	public void orderExecuted(){
		List<OrderBook> orderList = Arrays.asList(
	            new OrderBook("AAPL", "Buy", "Limit", 110.3, 415,Timestamp.valueOf("2017-02-02 14:42:50.078")),
	            new OrderBook("GOOGL", "Buy", "Limit", 760.76, 30,Timestamp.valueOf("2017-02-02 14:43:51.039")),
	            new OrderBook("IBM", "Sell", "Market", 0, 500,Timestamp.valueOf("2017-02-02 15:43:55.067")),
	            new OrderBook("AAPL", "Sell", "Market", 0, 40,Timestamp.valueOf("2017-02-02 15:43:57.009")),
	            new OrderBook("GOOGL", "Sell", "Market", 0, 10,Timestamp.valueOf("2017-02-02 16:02:52.009")),
	            new OrderBook("OTC", "Buy", "Limit", 85.87, 55,Timestamp.valueOf("2017-02-02 16:07:54.025")),
	            new OrderBook("AAPL", "Sell", "Limit", 109.80, 500,Timestamp.valueOf("2017-02-02 17:42:12.036"))
				);
		
		List<OrderComplete> orderComplete = Arrays.asList(
				 new OrderComplete("AAPL", 110.03, 40,Timestamp.valueOf("2017-02-02 15:43:57.009")),
				 new OrderComplete("GOOGL", 760.76, 10,Timestamp.valueOf("2017-02-02 16:02:52.009")),
				 new OrderComplete("AAPL", 109.80, 375,Timestamp.valueOf("2017-02-02 17:42:12.036"))
				);
		
		
		
		
		Response response = given().
				header("Content-Type", "application/json").
		body(orderList).
        when().
        	post("/trade/orders").
        then().
        	statusCode(HttpStatus.SC_OK).
        and().
        	extract().response();
		
		OrderComplete[] responseBody = response.as(OrderComplete[].class);
	    assertNotNull(responseBody);
	    
	    assertThat("Data matches successfully",3,equalTo(orderComplete.size()));
		
    }
}
