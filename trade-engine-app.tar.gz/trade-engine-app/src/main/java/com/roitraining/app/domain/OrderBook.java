package com.roitraining.app.domain;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class OrderBook extends BaseOrder{


	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderId;
	private String side;
	private String orderType;

	
	public OrderBook() {
		
	}
	
	
	
	public OrderBook(String tickerName, String side, String orderType, double price, int noOfShares, 
			Timestamp orderDate) {
		super(tickerName,price,noOfShares,orderDate);
		this.side = side;
		this.orderType = orderType;
	}
	
	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getSide() {
		return side;
	}
	public void setSide(String side) {
		this.side = side;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}



	@Override
	public String toString() {
		return "OrderBook [orderId=" + orderId + ", side=" + side + ", orderType=" + orderType 
				+ ", tickerName="
				+ getTickerName() + ", price=" + getPrice() + ", noOfShares=" + getNoOfShares()
				+ ", orderDate=" + getOrderDate()  + "]";
	}
	
	
}
