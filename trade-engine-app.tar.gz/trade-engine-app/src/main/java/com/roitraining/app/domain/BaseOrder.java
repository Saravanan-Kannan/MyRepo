package com.roitraining.app.domain;
import java.sql.Timestamp;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class BaseOrder {
	
	
	private String tickerName;
	private double price;
	private int noOfShares;
	private Timestamp orderDate;
	
	public BaseOrder() {}
	
	
	public BaseOrder(String tickerName, double price, int noOfShares, Timestamp orderDate) {
		super();
		this.tickerName = tickerName;
		this.price = price;
		this.noOfShares = noOfShares;
		this.orderDate = orderDate;
	}
	public String getTickerName() {
		return tickerName;
	}
	public void setTickerName(String tickerName) {
		this.tickerName = tickerName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getNoOfShares() {
		return noOfShares;
	}
	public void setNoOfShares(int noOfShares) {
		this.noOfShares = noOfShares;
	}
	public Timestamp getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Timestamp orderDate) {
		this.orderDate = orderDate;
	}
	@Override
	public String toString() {
		return "BaseOrder [tickerName=" + tickerName + ", price=" + price + ", noOfShares=" + noOfShares
				+ ", orderDate=" + orderDate + "]";
	}
	
	
	
	
}
