package com.roitraining.app.services.support;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.roitraining.app.domain.OrderBook;
import com.roitraining.app.domain.OrderComplete;
import com.roitraining.app.repositories.OrderCompleteRepository;
import com.roitraining.app.repositories.StockExchangeRepository;

@Component
public class StockExchangeService {

	@Autowired
	private StockExchangeRepository stockExchangeRepository;

	@Autowired
	private OrderCompleteRepository orderCompleteRepository;

	private List<OrderBook> orderList = new ArrayList<OrderBook>();

	@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public List<OrderBook> loadData(int inputCount) throws Exception{
		List<OrderBook> orderBook = new ArrayList<OrderBook>();
		String[] stockName = { "AAPL", "GOOGL", "IBM", "OTC", "FIDELITY" };
		double[] priceBase = { 105.0, 760.0, 233.0, 80.0, 432.0 };
		double[] priceDiff = { 10, 20, 10, 10, 20 };
		String[] side = { "Buy", "Sell" };
		String[] type = { "Limit", "Market" };
		
		if(inputCount == 0)
			inputCount = 10;
		
		Random rand = new Random();
		OrderBook orBook = null;
		for (int count = 0; count < inputCount; count++) {
			orBook = new OrderBook();
			int stockRan = rand.nextInt(5);
			int sideRan = rand.nextInt(2);
			int typeRan = rand.nextInt(2);
			float priceVal = rand.nextFloat();
			int numberofShare = rand.nextInt(500) + 1;

			orBook.setTickerName(stockName[stockRan]);
			orBook.setSide(side[sideRan]);
			orBook.setOrderType(type[typeRan]);
			orBook.setNoOfShares(numberofShare);
			if (typeRan == 1)
				orBook.setPrice(0);
			else
				orBook.setPrice((double) Math.round((priceBase[stockRan] 
						+ (priceVal * priceDiff[stockRan])) * 100)/100);

			
			orBook.setOrderDate(new Timestamp(System.currentTimeMillis()));
			
			orderBook.add(orBook);
		}
		
		stockExchangeRepository.save(orderBook);
		return stockExchangeRepository.findAllByOrderByOrderDate();
	}

	@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public List<OrderComplete> executeOrder(List<OrderBook> orderBook) throws Exception{
		if (orderBook == null || orderBook.size() == 0) {
			System.out.println("Order book is empty");
			return null;
		}
		List<OrderBook> orderBookOut = (List<OrderBook>)stockExchangeRepository.save(orderBook);
		if(orderList == null || orderList.size() ==0)
			orderList = (List<OrderBook>) stockExchangeRepository.findAllByOrderByOrderDate();
		else
			orderList.addAll(orderBookOut);
		
		List<OrderComplete> orderCompleteList = processOrder(orderBookOut);
		return (List<OrderComplete>)orderCompleteRepository.save(orderCompleteList);

	}
	
	@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public List<OrderBook> placeOrder(List<OrderBook> orderBook) throws Exception{
		if (orderBook == null || orderBook.size() == 0) {
			System.out.println("Order book is empty");
			return null;
		}
		List<OrderBook> orderBookOut = (List<OrderBook>)stockExchangeRepository.save(orderBook);
		if(orderList == null || orderList.size() ==0)
			orderList = (List<OrderBook>) stockExchangeRepository.findAllByOrderByOrderDate();
		else
			orderList.addAll(orderBookOut);
		processOrder(orderBookOut);
		return orderBookOut;

	}
	
	@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public List<OrderBook> cancelOrder(List<OrderBook> orderBook) throws Exception{
		if (orderBook == null || orderBook.size() == 0) {
			System.out.println("Order book is empty");
			return null;
		}
		int cancelCount = -1;
		for (int i = 0; i < orderList.size(); i++) {
			if(orderList.get(i).getOrderId() == orderBook.get(0).getOrderId()) {
				cancelCount = i;
				break;
			}
		}
		OrderBook removedBook = null;
		if(cancelCount > -1) {
			removedBook = orderList.remove(cancelCount);
		}else {
			return null;
		}
		List<OrderBook> orderBookOut = Arrays.asList(removedBook);
		return orderBookOut;

	}

	private List<OrderComplete> processOrder(List<OrderBook> orderBook) {
		List<OrderComplete> orderCompleteList = new ArrayList<OrderComplete>();

		for (int i = 0; i < orderList.size(); i++) {
			OrderBook orBook = orderList.get(i);

			for (int j = 0; j < orderList.size(); j++) {
				if (i != j) {
					OrderBook subOrder = orderList.get(j);
					if (subOrder.getTickerName().equalsIgnoreCase(orBook.getTickerName())
							&& !orBook.getSide().equalsIgnoreCase(subOrder.getSide())) {
						if (orBook.getNoOfShares() > 0 && subOrder.getNoOfShares() > 0
								&& ((orBook.getOrderType().equals("Limit") && subOrder.getOrderType().equals("Limit")
										&& orBook.getPrice() >= subOrder.getPrice())
										|| (orBook.getOrderType().equals("Market")
												&& subOrder.getOrderType().equals("Limit"))
										|| (orBook.getOrderType().equals("Limit")))) {
							int execCounts = 0;

							if (orBook.getNoOfShares() > subOrder.getNoOfShares()) {
								execCounts = subOrder.getNoOfShares();
							} else {
								execCounts = orBook.getNoOfShares();
							}

							double price = 0.0;
							if (orBook.getOrderType().equals("Market") || (orBook.getOrderType().equals("Limit")
									&& !subOrder.getOrderType().equals("Market")
									&& orBook.getPrice() > subOrder.getPrice())) {
								price = subOrder.getPrice();
							} else {
								price = orBook.getPrice();
							}

							orderList.get(i).setNoOfShares(orBook.getNoOfShares() - execCounts);
							orderList.get(j).setNoOfShares(subOrder.getNoOfShares() - execCounts);
							
							if(orderBook.contains(orBook))
								orderCompleteList.add(new OrderComplete(orBook.getTickerName(), price, execCounts,
									subOrder.getOrderDate()));
						}
					}
				}
			}

		}

		return orderCompleteList;
	}
}
