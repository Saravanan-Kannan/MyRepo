package com.roitraining.app.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.roitraining.app.domain.OrderBook;
import com.roitraining.app.domain.OrderComplete;
import com.roitraining.app.services.support.StockExchangeService;

@RestController
public class StockExchangeController {
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private StockExchangeService stockExchangeService;

	@RequestMapping(value = "/trade/loadData", method = RequestMethod.GET)
	public ResponseEntity<?> loadData(@RequestParam("loadCount") Integer loadCount) {
		try {
			List<OrderBook> orderList = stockExchangeService.loadData(loadCount);
			return new ResponseEntity<List<OrderBook>>(orderList, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<String>("Not able to load the data", HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(value = "/trade/orders", method = RequestMethod.POST, consumes = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	private ResponseEntity<?> executeOrders(@RequestBody List<OrderBook> orderBook) {
		log.info(orderBook.toString());
		try {
			List<OrderComplete> rtnList = stockExchangeService.executeOrder(orderBook);
			return new ResponseEntity<List<OrderComplete>>(rtnList, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<String>("Not able to process the order", HttpStatus.BAD_REQUEST);
		}

	}
	
	@RequestMapping(value = "/trade/placeorder", method = RequestMethod.POST, consumes = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	private ResponseEntity<?> placeOrder(@RequestBody List<OrderBook> orderBook) {
		log.info(orderBook.toString());
		try {
			List<OrderBook> rtnList = stockExchangeService.placeOrder(orderBook);
			return new ResponseEntity<List<OrderBook>>(rtnList, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<String>("Not able to process the order", HttpStatus.BAD_REQUEST);
		}

	}
	
	@RequestMapping(value = "/trade/cancel", method = RequestMethod.POST, consumes = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	private ResponseEntity<?> cancelOrder(@RequestBody List<OrderBook> orderBook) {
		log.info(orderBook.toString());
		try {
			List<OrderBook> rtnList = stockExchangeService.cancelOrder(orderBook);
			if(rtnList ==null || rtnList.size() ==0) {
				return new ResponseEntity<String>("Not able to cancel the order", HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<List<OrderBook>>(rtnList, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<String>("Not able to cancel the order", HttpStatus.BAD_REQUEST);
		}

	}

}
