package com.roitraining.app.domain;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class OrderComplete extends BaseOrder{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderCompleteid;
	
	
	public OrderComplete() {}
	
	
	public OrderComplete(String tickerName, double price, int noOfShares, Timestamp orderDate) {
		super(tickerName,price,noOfShares,orderDate);
	}


	public int getOrderCompleteid() {
		return orderCompleteid;
	}


	public void setOrderCompleteid(int orderCompleteid) {
		this.orderCompleteid = orderCompleteid;
	}


	@Override
	public String toString() {
		return "OrderComplete [orderCompleteid=" + orderCompleteid + ", tickerName=" + getTickerName()
				+ ", price=" + getPrice() + ", noOfShares=" + getNoOfShares() + ", orderDate="
				+ getOrderDate() + "]";
	}


	


}
