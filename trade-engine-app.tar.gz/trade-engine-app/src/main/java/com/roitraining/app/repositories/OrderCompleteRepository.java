package com.roitraining.app.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.roitraining.app.domain.OrderComplete;

public interface OrderCompleteRepository extends CrudRepository<OrderComplete, Long>{

	List<OrderComplete> findAllByOrderByOrderDate();
}
