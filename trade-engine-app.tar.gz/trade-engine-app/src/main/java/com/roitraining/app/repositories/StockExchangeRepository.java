package com.roitraining.app.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.roitraining.app.domain.OrderBook;

public interface StockExchangeRepository extends CrudRepository<OrderBook, Long>{

	List<OrderBook> findAllByOrderByOrderDate();
}
